// Chatbot functionality
document.querySelector('.send-btn').addEventListener('click', sendMessage);
document.getElementById('user-input').addEventListener('keypress', function(e) {
    if(e.key === 'Enter') sendMessage();
});

function sendMessage() {
    const userInput = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');
    
    if(userInput.value.trim() === '') return;
    
    // Add user message
    chatBox.innerHTML += `
        <div class="message user-message">
            <span>You:</span> ${userInput.value}
        </div>
    `;
    
    // Simulate AI response
    setTimeout(() => {
        chatBox.innerHTML += `
            <div class="message bot-message">
                <span>Serenity:</span> Thank you for sharing. I'm here to help. Let's explore some coping strategies together.
            </div>
        `;
        chatBox.scrollTop = chatBox.scrollHeight;
    }, 1000);
    
    userInput.value = '';
}

// Smooth scroll functionality
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Mobile menu toggle (can be expanded later)
const navbar = document.querySelector('.navbar');
window.addEventListener('scroll', () => {
    if(window.scrollY > 100) {
        navbar.style.backgroundColor = 'rgba(255,255,255,0.95)';
    } else {
        navbar.style.backgroundColor = '#ffffff';
    }
});