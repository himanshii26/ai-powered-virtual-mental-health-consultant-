// Form Validation and Submission
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form values
    const email = this.querySelector('input[type="email"]').value;
    const password = this.querySelector('input[type="password"]').value;
    
    // Simple validation
    if (!validateEmail(email)) {
        showError('Please enter a valid email address');
        return;
    }
    
    if (password.length < 8) {
        showError('Password must be at least 8 characters');
        return;
    }
    
    // Simulate API call
    showLoading();
    setTimeout(() => {
        hideLoading();
        alert('Login successful!');
        this.reset();
    }, 1500);
});

// Helper functions
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    errorDiv.style.color = '#ff4757';
    errorDiv.style.marginBottom = '20px';
    errorDiv.style.textAlign = 'center';
    
    const form = document.getElementById('loginForm');
    form.prepend(errorDiv);
    
    setTimeout(() => {
        errorDiv.remove();
    }, 3000);
}

function showLoading() {
    const btn = document.querySelector('.login-btn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    btn.disabled = true;
}

function hideLoading() {
    const btn = document.querySelector('.login-btn');
    btn.innerHTML = 'Sign In';
    btn.disabled = false;
}

// Add input animations
document.querySelectorAll('.input-group input').forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.style.transform = 'scale(1.02)';
    });
    
    input.addEventListener('blur', function() {
        this.parentElement.style.transform = 'scale(1)';
    });
});